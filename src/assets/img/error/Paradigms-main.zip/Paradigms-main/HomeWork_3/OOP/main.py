from game import Games_XO

if __name__ == '__main__':
    game = Games_XO()
    game.play()


